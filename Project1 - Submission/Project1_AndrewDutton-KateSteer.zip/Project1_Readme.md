THIS PROGRAM WILL ONLY WORK IN A LINUX ENVIRONMENT

This program can be complied with G++ or C++ using "G++ Project1.cpp -o "FileName"" 

You can run the file in this format: "outputFileName" fileOne.ext fileTwo.ext

It will copy any file of any type from fileOne to FileTwo

This program acts as the "copy" call in a linux environment

All the lab code is in Project1.cpp

test.txt is a text file that can be used for testing the copy function.